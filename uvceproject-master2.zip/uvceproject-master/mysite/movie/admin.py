from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Movie)
admin.site.register(Contact)
admin.site.register(Rent)
admin.site.register(Seen)
admin.site.register(Watch)
admin.site.register(Payment)
